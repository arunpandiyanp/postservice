//
//  ViewController.h
//  postservice
//
//  Created by Green on 8/22/15.
//  Copyright (c) 2015 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    NSMutableData *receivedData;
 }

@end

