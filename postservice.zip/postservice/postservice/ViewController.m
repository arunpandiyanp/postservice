//
//  ViewController.m
//  postservice
//
//  Created by Green on 8/22/15.
//  Copyright (c) 2015 Greens. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [receivedData setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [receivedData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
   NSDictionary *d1=[[NSMutableDictionary alloc]init];
    d1=[NSJSONSerialization JSONObjectWithData:receivedData options:NSJSONReadingAllowFragments error:nil];
    NSLog(@"d1-->%@",d1);
}


-(void)postMethod:(NSMutableDictionary *)postService
{
//    NSData *postData = [postService
//                        dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    NSData *postData = [NSJSONSerialization dataWithJSONObject:postService options:0 error:nil];
    
    
    NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[postData length]];
    
    NSLog(@"Post date--> %@ , Post length--> %@ ", postData, postLength);
   
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:@"http://rotary3230.in/16-17/club_roster/restphp/login"]];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody:postData];

    NSLog(@"request-->%@",request);
    

    NSURLConnection *theConnection = [[NSURLConnection alloc] initWithRequest:request delegate:self ];
    if (theConnection)
    {
        receivedData=[NSMutableData data];
    }
    else
    {
        NSLog(@"Connection Failed!");
        // inform the user that the download could not be made
    }

}

//    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
//    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
//
//        //NSError *error;
//       // self.data_dictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
//
//
//       // NSLog(@"self.data_dictionary-->%@",self.data_dictionary);
//        //NSString *requestReply = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
//        //NSLog(@"requestReply: %@", requestReply);
//    }] resume];

- (void)viewDidLoad {
    
  // NSString  *string=@"value=getCountry";
    
    NSMutableDictionary  *dict = [[NSMutableDictionary alloc]init];
    [dict setObject:@"bala@amshuhu.com" forKey:@"email"];
    [dict setObject:@"amshuhu2014" forKey:@"password"];

    [self postMethod:dict];
    
    /*
     NSDictionary *tmp = [[NSDictionary alloc] initWithObjectsAndKeys:
     email, @"Email",
     fname, @"FirstName",
     nil];
     NSError *error;
     NSData *postdata = [NSJSONSerialization dataWithJSONObject:tmp options:0 error:&error];
     [request setHTTPBody:postData];
     */
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
